gcc -g -o i3_fft i3.c fft.c -Wall -lm
./i3_fft $1 50000